package com.bomshop.www.goods.vo;

import lombok.Data;

@Data
public class Goods_OptionVO {
	
	private int ono;
	private int gno;
	private String size;
	private String color;
	private int count;

}
