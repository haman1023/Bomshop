package com.bomshop.www.seller.dto;

import com.bomshop.www.seller.vo.QnAGoodsVO;

import lombok.Data;

@Data
public class QnAGoodsDTO {
	private QnAGoodsVO qna;
	private String gname;
	private String mid;
}
