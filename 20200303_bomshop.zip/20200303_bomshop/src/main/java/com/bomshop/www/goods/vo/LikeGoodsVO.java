package com.bomshop.www.goods.vo;

import lombok.Data;

@Data
public class LikeGoodsVO {
	private int mno;
	private int gno;
}
