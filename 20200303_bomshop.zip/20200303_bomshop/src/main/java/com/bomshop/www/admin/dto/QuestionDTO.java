package com.bomshop.www.admin.dto;

import com.bomshop.www.admin.vo.QuestionVO;

import lombok.Data;

@Data
public class QuestionDTO {
	private QuestionVO questionVO;
	private String questionID;
}
