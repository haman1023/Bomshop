package com.bomshop.www.seller.vo;

import java.util.Date;

import lombok.Data;

@Data
public class AdvertiseVO {
	private int ano;
	private int gno;
	private String gname_ko;
	private Date adate;
	private int astatus;
}
