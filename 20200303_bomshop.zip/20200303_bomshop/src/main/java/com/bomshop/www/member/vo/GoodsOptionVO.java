package com.bomshop.www.member.vo;

import lombok.Data;

@Data
public class GoodsOptionVO {
	private int ono;
	private int gno;
	private String size;
	private String color;
	private int count;
}
