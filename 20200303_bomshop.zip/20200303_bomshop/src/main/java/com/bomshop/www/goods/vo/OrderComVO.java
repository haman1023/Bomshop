package com.bomshop.www.goods.vo;

import lombok.Data;

@Data
public class OrderComVO {
	
	private int orderno;
	private String gname_ko;
	private String color;
	private String size;
	private String order_email;
}
