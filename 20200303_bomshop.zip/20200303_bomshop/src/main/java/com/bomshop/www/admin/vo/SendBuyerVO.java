package com.bomshop.www.admin.vo;

import lombok.Data;

@Data
public class SendBuyerVO {
	
	private int rgno;
	private String buyerID;
	private String goodsName;
	private String reason;
	
}
