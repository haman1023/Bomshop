package com.bomshop.www.admin.dto;

import com.bomshop.www.admin.vo.ReportVO;

import lombok.Data;

@Data
public class reportDTO {

	private ReportVO reportVO;
	private String reporterID;
	private String reportID;
	
}
