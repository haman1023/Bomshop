package com.bomshop.www.member.vo;

import lombok.Data;

@Data
public class LikeGoodsVO {
	private int mno;
	private int gno;
}
