package com.bomshop.www.common.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bomshop.www.common.util.SearchCriteria;
import com.bomshop.www.goods.service.GoodsService;

@Controller
public class HomeController {
	
	@Inject
	GoodsService gs;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(@ModelAttribute("cri") SearchCriteria cri, Model model) {
		return "redirect:/goods/main";
	}
	
}
