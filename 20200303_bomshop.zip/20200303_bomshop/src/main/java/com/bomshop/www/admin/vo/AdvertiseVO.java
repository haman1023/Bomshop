package com.bomshop.www.admin.vo;

import java.util.Date;

import lombok.Data;

@Data
public class AdvertiseVO {

	private int ano;
	private int gno;
	private Date adate;
	private int astatus;
	
}
