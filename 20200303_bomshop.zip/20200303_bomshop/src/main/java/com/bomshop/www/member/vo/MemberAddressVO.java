package com.bomshop.www.member.vo;

import lombok.Data;

@Data
public class MemberAddressVO {
	private int mano;
	private int mno;
	private String post_code;
	private String addr1;
	private String addr2;
	private String memo;
}
