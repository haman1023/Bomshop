update member_address set memo = '기본주소지' where post_code='39310';

insert into goods(cat1,cat2,gname_ko,gname_en,sdate,cost_origin,cost,img1,gdetail,gexchange,gmodel,scount) 
values('상의','자켓','자켓테스트','jakettest',now(),50000,48000,'','detail','반품정보당','모델정보당',3);

select * from goods;

insert into goods_option(gno, size, color, count)
VALUES(1, 95, "black", 20);
insert into goods_option(gno, size, color, count)
VALUES(1, 95, "gray", 20);
insert into goods_option(gno, size, color, count)
VALUES(1, 95, "green", 20);

insert into goods_option(gno, size, color, count)
VALUES(1, 100, "black", 20);
insert into goods_option(gno, size, color, count)
VALUES(1, 100, "gray", 20);
insert into goods_option(gno, size, color, count)
VALUES(1, 100, "green", 20);

insert into goods_option(gno, size, color, count)
VALUES(1, 105, "black", 20);
insert into goods_option(gno, size, color, count)
VALUES(1, 105, "gray", 20);
insert into goods_option(gno, size, color, count)
VALUES(1, 105, "green", 20);

insert into goods_option(gno, size, color, count)
VALUES(2, 95, "black", 20);
insert into goods_option(gno, size, color, count)
VALUES(2, 95, "gray", 20);
insert into goods_option(gno, size, color, count)
VALUES(2, 95, "green", 20);

insert into goods_option(gno, size, color, count)
VALUES(2, 100, "black", 20);
insert into goods_option(gno, size, color, count)
VALUES(2, 100, "gray", 20);
insert into goods_option(gno, size, color, count)
VALUES(2, 100, "green", 20);

insert into goods_option(gno, size, color, count)
VALUES(2, 105, "black", 20);
insert into goods_option(gno, size, color, count)
VALUES(2, 105, "gray", 20);
insert into goods_option(gno, size, color, count)
VALUES(2, 105, "green", 20);

select * from goods_option;

insert into order_member(ono,mno,count,price,orderdate,order_name,delivery_name,delivery_addr,order_status) 
values(2,8,1,89000,now(),'김문영','김문영','형곡동 우방3차 303동 202호',2);
update order_member set order_status = 2 WHERE orderno = 3;
select * from order_com;
update order_member set order_check = 'Y' where order_status > 0;

insert into order_com(mno,ono,count,price,order_date) values(8,3,1,89000,'2020-01-01');
insert into order_com(mno,ono,count,price,order_date) values(8,3,1,89000,now());

SELECT * FROM order_com WHERE mno = 8 AND order_date BETWEEN DATE_ADD(now(),interval -7 day) and now() ORDER BY order_date DESC;

delete from mail_code where mail_code = 'yeoung9381@naver.com';